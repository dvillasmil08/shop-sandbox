import { useState, createContext, useContext, useRef, useEffect } from "react";

const SettingsContext = createContext({ taxRate: 8.0, taxMode: "all", taxableItems: [] });
const useSettings = () => useContext(SettingsContext);

const SQUARE_APP_ID = "sandbox-sq0idb-G5on8gjZOOxBOozksNFTuw";
const SQUARE_LOCATION_ID = "LYP5JVKSKCM42";
const SQUARE_ENV = "sandbox";

const ARTISTS = ["Alex Rivera", "Sam Chen", "Jordan Lee"];
const SERVICES = [
  { name: "Small Tattoo (< 3in)", price: 100, duration: "1 hr" },
  { name: "Medium Tattoo (3-6in)", price: 200, duration: "2 hrs" },
  { name: "Large Tattoo (6in+)", price: 350, duration: "3-4 hrs" },
  { name: "Touch-Up", price: 60, duration: "30 min" },
  { name: "Consultation", price: 0, duration: "30 min" },
  { name: "Piercing", price: 80, duration: "30 min" },
  { name: "Merch / Products", price: 0, duration: "" },
];
const ALL_ITEM_NAMES = SERVICES.map(s => s.name);
const NAV_ITEMS = [
  { id: "booking", label: "Book", icon: "📅" },
  { id: "checkout", label: "Checkout", icon: "💳" },
  { id: "cash", label: "Cash", icon: "💵" },
  { id: "tips", label: "Tips", icon: "💰" },
  { id: "dashboard", label: "Dashboard", icon: "📊" },
  { id: "settings", label: "Settings", icon: "⚙️" },
];
const TIMES = ["10:00 AM", "11:00 AM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM"];
const mockAppointments = [
  { name: "Maria G.", service: "Medium Tattoo (3-6in)", artist: "Alex Rivera", time: "10:00 AM", date: "Today", status: "confirmed", amount: 200 },
  { name: "Derek T.", service: "Large Tattoo (6in+)", artist: "Sam Chen", time: "1:00 PM", date: "Today", status: "confirmed", amount: 350 },
  { name: "Priya K.", service: "Touch-Up", artist: "Jordan Lee", time: "3:00 PM", date: "Today", status: "pending", amount: 60 },
  { name: "Josh M.", service: "Consultation", artist: "Alex Rivera", time: "11:00 AM", date: "Tomorrow", status: "confirmed", amount: 0 },
];
const mockSales = [
  { label: "Mon", card: 550, cash: 120 },
  { label: "Tue", card: 710, cash: 200 },
  { label: "Wed", card: 350, cash: 60 },
  { label: "Thu", card: 900, cash: 300 },
  { label: "Fri", card: 1100, cash: 450 },
  { label: "Sat", card: 1400, cash: 600 },
  { label: "Sun", card: 620, cash: 180 },
];

const calcTax = (amount, rate) => parseFloat(((amount * rate) / 100).toFixed(2));
const calcTotal = (amount, rate) => parseFloat((amount + calcTax(amount, rate)).toFixed(2));

// ─── Styles ───────────────────────────────────────────────────────────────────
const S = {
  app: { fontFamily: "'Inter','Helvetica Neue',sans-serif", background: "#f5f5f5", minHeight: "100vh", display: "flex", flexDirection: "column", color: "#111" },
  header: { background: "#111", color: "#fff", padding: "0 20px", height: 56, display: "flex", alignItems: "center", justifyContent: "space-between" },
  logo: { fontSize: 14, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase" },
  taxBadge: { fontSize: 11, background: "#222", padding: "3px 10px", borderRadius: 4, color: "#ccc", border: "1px solid #333" },
  nav: { background: "#fff", borderBottom: "1px solid #e5e5e5", display: "flex", overflowX: "auto", padding: "0 4px" },
  navBtn: (active) => ({ padding: "14px 11px", fontSize: 12, fontWeight: active ? 600 : 400, color: active ? "#111" : "#666", borderBottom: active ? "2px solid #111" : "2px solid transparent", background: "none", border: "none", cursor: "pointer", whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: 4 }),
  main: { flex: 1, padding: "20px 16px", maxWidth: 760, margin: "0 auto", width: "100%", boxSizing: "border-box" },
  card: { background: "#fff", border: "1px solid #e5e5e5", borderRadius: 8, padding: 20, marginBottom: 16 },
  h2: { fontSize: 17, fontWeight: 700, marginBottom: 16 },
  h3: { fontSize: 11, fontWeight: 600, color: "#555", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 12 },
  label: { fontSize: 13, fontWeight: 500, color: "#444", display: "block", marginBottom: 6 },
  input: { width: "100%", padding: "10px 12px", border: "1px solid #ddd", borderRadius: 6, fontSize: 14, outline: "none", boxSizing: "border-box", background: "#fafafa" },
  select: { width: "100%", padding: "10px 12px", border: "1px solid #ddd", borderRadius: 6, fontSize: 14, background: "#fafafa", boxSizing: "border-box" },
  row: { display: "flex", gap: 12, marginBottom: 14 },
  col: { flex: 1 },
  mb: (n) => ({ marginBottom: n }),
  btnPrimary: { background: "#111", color: "#fff", border: "none", borderRadius: 6, padding: "12px 20px", fontSize: 14, fontWeight: 600, cursor: "pointer", width: "100%" },
  btnSecondary: { background: "#fff", color: "#111", border: "1px solid #ddd", borderRadius: 6, padding: "10px 16px", fontSize: 13, fontWeight: 500, cursor: "pointer" },
  btnGhost: (active) => ({ background: active ? "#111" : "#f5f5f5", color: active ? "#fff" : "#444", border: "1px solid " + (active ? "#111" : "#e5e5e5"), borderRadius: 6, padding: "8px 14px", fontSize: 13, cursor: "pointer", fontWeight: active ? 600 : 400 }),
  tag: (color) => ({ display: "inline-block", fontSize: 11, fontWeight: 600, padding: "2px 8px", borderRadius: 4, background: color === "green" ? "#e8f5e9" : color === "yellow" ? "#fff8e1" : color === "blue" ? "#e8f0fe" : color === "red" ? "#fde8e8" : "#f5f5f5", color: color === "green" ? "#2e7d32" : color === "yellow" ? "#f57f17" : color === "blue" ? "#1a56db" : color === "red" ? "#c00" : "#555", textTransform: "uppercase" }),
  divider: { borderTop: "1px solid #e5e5e5", margin: "12px 0" },
  statGrid: { display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12, marginBottom: 16 },
  statCard: (accent) => ({ background: accent ? "#111" : "#fff", border: "1px solid " + (accent ? "#111" : "#e5e5e5"), borderRadius: 8, padding: 16, color: accent ? "#fff" : "#111" }),
  statNum: { fontSize: 24, fontWeight: 800, lineHeight: 1.1 },
  statLabel: (accent) => ({ fontSize: 11, color: accent ? "#aaa" : "#777", marginTop: 4, textTransform: "uppercase", letterSpacing: "0.06em" }),
  apptRow: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 0", borderBottom: "1px solid #f0f0f0" },
  apptName: { fontSize: 14, fontWeight: 600 },
  apptSub: { fontSize: 12, color: "#777", marginTop: 2 },
  successBox: { background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 8, padding: 24, textAlign: "center" },
  errorBox: { background: "#fde8e8", border: "1px solid #fca5a5", borderRadius: 8, padding: 16, textAlign: "center", marginBottom: 16 },
  tipBox: { border: "1px solid #e5e5e5", borderRadius: 8, padding: 20, textAlign: "center", marginBottom: 12 },
  qr: { width: 80, height: 80, background: "#111", borderRadius: 6, margin: "8px auto", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 28 },
  taxLine: { display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 4 },
  taxTotal: { display: "flex", justifyContent: "space-between", fontWeight: 700, fontSize: 15 },
  infoBox: { background: "#f0f4ff", border: "1px solid #c7d7ff", borderRadius: 6, padding: 12, fontSize: 12, color: "#3355aa", marginBottom: 16 },
  warnBox: { background: "#fffbeb", border: "1px solid #fde68a", borderRadius: 8, padding: 14, fontSize: 12, color: "#92400e" },
  toggleWrap: { display: "flex", background: "#f0f0f0", borderRadius: 8, padding: 3, marginBottom: 16 },
  toggleBtn: (active) => ({ flex: 1, padding: "9px 12px", fontSize: 13, fontWeight: active ? 600 : 400, background: active ? "#fff" : "transparent", color: active ? "#111" : "#777", border: "none", borderRadius: 6, cursor: "pointer", boxShadow: active ? "0 1px 3px rgba(0,0,0,0.1)" : "none" }),
  dropdownWrap: { position: "relative" },
  dropdownTrigger: (open) => ({ width: "100%", padding: "10px 12px", border: "1px solid " + (open ? "#111" : "#ddd"), borderRadius: 6, fontSize: 13, background: "#fafafa", cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center", boxSizing: "border-box" }),
  dropdownMenu: { position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0, background: "#fff", border: "1px solid #ddd", borderRadius: 8, boxShadow: "0 4px 16px rgba(0,0,0,0.1)", zIndex: 100, overflow: "hidden" },
  dropdownItem: (selected) => ({ display: "flex", alignItems: "center", gap: 10, padding: "11px 14px", cursor: "pointer", background: selected ? "#f0f4ff" : "#fff", borderBottom: "1px solid #f5f5f5", fontSize: 13 }),
  checkbox: (checked) => ({ width: 16, height: 16, borderRadius: 4, border: "2px solid " + (checked ? "#111" : "#ccc"), background: checked ? "#111" : "#fff", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }),
  // Square card form container
  squareCard: { minHeight: 90, background: "#fafafa", border: "1px solid #ddd", borderRadius: 6, padding: "12px", marginBottom: 16 },
  squareTestCard: { background: "#f0f4ff", border: "1px solid #c7d7ff", borderRadius: 6, padding: 10, fontSize: 12, color: "#3355aa", marginBottom: 12 },
};

// ─── Multi-select Dropdown ────────────────────────────────────────────────────
function MultiSelect({ options, selected, onChange }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const toggle = (item) => onChange(selected.includes(item) ? selected.filter(i => i !== item) : [...selected, item]);
  const label = selected.length === 0 ? "Select items..." : selected.length === options.length ? "All items" : selected.length === 1 ? selected[0] : `${selected.length} items selected`;
  return (
    <div style={S.dropdownWrap} ref={ref}>
      <div style={S.dropdownTrigger(open)} onClick={() => setOpen(o => !o)}>
        <span style={{ color: selected.length === 0 ? "#aaa" : "#111" }}>{label}</span>
        <span style={{ fontSize: 10, color: "#888" }}>{open ? "▲" : "▼"}</span>
      </div>
      {open && (
        <div style={S.dropdownMenu}>
          <div style={{ ...S.dropdownItem(selected.length === options.length), fontWeight: 600, borderBottom: "2px solid #f0f0f0" }} onClick={() => onChange(selected.length === options.length ? [] : [...options])}>
            <div style={S.checkbox(selected.length === options.length)}>{selected.length === options.length && <span style={{ color: "#fff", fontSize: 10 }}>✓</span>}</div>
            Select All
          </div>
          {options.map(item => (
            <div key={item} style={S.dropdownItem(selected.includes(item))} onClick={() => toggle(item)}>
              <div style={S.checkbox(selected.includes(item))}>{selected.includes(item) && <span style={{ color: "#fff", fontSize: 10 }}>✓</span>}</div>
              {item}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Tax Breakdown ────────────────────────────────────────────────────────────
function TaxBreakdown({ subtotal, label, taxable = true }) {
  const { taxRate } = useSettings();
  const tax = taxable ? calcTax(subtotal, taxRate) : 0;
  const total = subtotal + tax;
  return (
    <div style={{ background: "#f5f5f5", borderRadius: 6, padding: 14, marginBottom: 16 }}>
      <div style={S.taxLine}>
        <span style={{ color: "#555" }}>{label || "Service"}</span>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {!taxable && <span style={S.tag("blue")}>tax exempt</span>}
          <span>${subtotal.toFixed(2)}</span>
        </div>
      </div>
      {taxable && <div style={S.taxLine}><span style={{ color: "#555" }}>Sales Tax ({taxRate}%)</span><span>${tax.toFixed(2)}</span></div>}
      <div style={S.divider} />
      <div style={S.taxTotal}><span>Total</span><span>${total.toFixed(2)}</span></div>
    </div>
  );
}

// ─── Square Payment Form ──────────────────────────────────────────────────────
function SquarePaymentForm({ amount, onSuccess, onError }) {
  const cardRef = useRef(null);
  const squareRef = useRef(null);
  const cardInstanceRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [paying, setPaying] = useState(false);
  const [sdkError, setSdkError] = useState(false);

  useEffect(() => {
    let mounted = true;

    const initSquare = async () => {
      // Load Square Web Payments SDK if not already loaded
      if (!window.Square) {
        const script = document.createElement("script");
        script.src = "https://sandbox.web.squarecdn.com/v1/square.js";
        script.onload = () => mounted && setupCard();
        script.onerror = () => { if (mounted) { setSdkError(true); setLoading(false); } };
        document.head.appendChild(script);
      } else {
        setupCard();
      }
    };

    const setupCard = async () => {
      try {
        if (!window.Square) throw new Error("Square SDK not available");
        const payments = window.Square.payments(SQUARE_APP_ID, SQUARE_LOCATION_ID);
        squareRef.current = payments;
        const card = await payments.card({
          style: {
            input: { color: "#111", fontSize: "14px", fontFamily: "Inter, Helvetica Neue, sans-serif" },
            ".input-container": { borderColor: "#ddd", borderRadius: "6px" },
            ".input-container.is-focus": { borderColor: "#111" },
          }
        });
        await card.attach("#sq-card-container");
        cardInstanceRef.current = card;
        if (mounted) setLoading(false);
      } catch (err) {
        console.error("Square init error:", err);
        if (mounted) { setSdkError(true); setLoading(false); }
      }
    };

    initSquare();
    return () => { mounted = false; };
  }, []);

  const handlePay = async () => {
    if (!cardInstanceRef.current) return;
    setPaying(true);
    try {
      const result = await cardInstanceRef.current.tokenize();
      if (result.status === "OK") {
        // In production: send result.token to your backend → Square Payments API
        // For sandbox demo we simulate success
        onSuccess({ token: result.token, amount });
      } else {
        const errs = result.errors?.map(e => e.message).join(", ") || "Card error";
        onError(errs);
      }
    } catch (err) {
      onError(err.message || "Payment failed");
    } finally {
      setPaying(false);
    }
  };

  if (sdkError) return (
    <div style={{ ...S.warnBox, marginBottom: 16 }}>
      ⚠️ Square SDK could not load in this preview environment. In your deployed Cloudflare app it will work fully. The rest of the app is fully functional.
    </div>
  );

  return (
    <div>
      <div style={S.squareTestCard}>
        🧪 <strong>Sandbox test card:</strong> 4111 1111 1111 1111 · CVV: 111 · Exp: any future date · ZIP: 12345
      </div>
      <div style={S.squareCard}>
        {loading && <div style={{ fontSize: 13, color: "#aaa", textAlign: "center", padding: "20px 0" }}>Loading secure card form...</div>}
        <div id="sq-card-container" />
      </div>
      <button style={{ ...S.btnPrimary, opacity: paying ? 0.7 : 1 }} onClick={handlePay} disabled={paying || loading}>
        {paying ? "Processing..." : `Pay $${amount.toFixed(2)} securely`}
      </button>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 6, marginTop: 10, fontSize: 11, color: "#aaa" }}>
        <span>🔒</span> Secured by Square · PCI compliant · No card data touches this app
      </div>
    </div>
  );
}

// ─── Checkout Screen ──────────────────────────────────────────────────────────
function CheckoutScreen() {
  const { taxRate, taxMode, taxableItems } = useSettings();
  const [selected, setSelected] = useState(null);
  const [method, setMethod] = useState("card");
  const [done, setDone] = useState(false);
  const [payError, setPayError] = useState("");
  const [cashReceived, setCashReceived] = useState("");

  const appt = selected !== null ? mockAppointments[selected] : null;
  const isTaxable = appt ? (taxMode === "all" || taxableItems.includes(appt.service)) : false;
  const tax = appt && isTaxable ? calcTax(appt.amount, taxRate) : 0;
  const total = appt ? parseFloat((appt.amount + tax).toFixed(2)) : 0;
  const cashChange = cashReceived ? parseFloat((parseFloat(cashReceived) - total).toFixed(2)) : null;

  const handleCardSuccess = () => { setPayError(""); setDone(true); };
  const handleCardError = (msg) => setPayError(msg);
  const handleCashPay = () => { if (!cashReceived || parseFloat(cashReceived) < total) { setPayError("Cash received is less than total."); return; } setDone(true); };

  if (done) return (
    <div style={S.successBox}>
      <div style={{ fontSize: 36, marginBottom: 8 }}>✅</div>
      <div style={{ fontSize: 17, fontWeight: 700, marginBottom: 4 }}>Payment Complete</div>
      <div style={{ fontSize: 13, color: "#555", marginBottom: 4 }}>
        ${total.toFixed(2)} via {method === "card" ? "Square card" : "cash"}
      </div>
      {method === "cash" && cashChange !== null && cashChange > 0 && (
        <div style={{ fontSize: 14, fontWeight: 700, color: "#2e7d32", marginBottom: 8 }}>Change due: ${cashChange.toFixed(2)}</div>
      )}
      <div style={{ fontSize: 12, color: "#888" }}>{isTaxable ? `Incl. $${tax.toFixed(2)} tax @ ${taxRate}%` : "Tax exempt"}</div>
      <button style={{ ...S.btnPrimary, maxWidth: 200, margin: "16px auto 0" }} onClick={() => { setDone(false); setSelected(null); setPayError(""); setCashReceived(""); }}>New Transaction</button>
    </div>
  );

  return (
    <div>
      <div style={S.card}>
        <div style={S.h2}>Today's Appointments</div>
        {mockAppointments.filter(a => a.date === "Today").map((a, i) => {
          const taxable = taxMode === "all" || taxableItems.includes(a.service);
          const t = taxable ? calcTax(a.amount, taxRate) : 0;
          return (
            <div key={i} style={{ ...S.apptRow, cursor: "pointer", background: selected === i ? "#f5f5f5" : "transparent", borderRadius: 6, padding: "12px 8px" }} onClick={() => { setSelected(i); setPayError(""); setCashReceived(""); }}>
              <div><div style={S.apptName}>{a.name}</div><div style={S.apptSub}>{a.service} · {a.artist} · {a.time}</div></div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontWeight: 700, fontSize: 15 }}>${(a.amount + t).toFixed(2)}</div>
                <div style={{ fontSize: 11, color: "#999" }}>{taxable ? `+${taxRate}% tax` : "tax exempt"}</div>
                <div style={S.tag(a.status === "confirmed" ? "green" : "yellow")}>{a.status}</div>
              </div>
            </div>
          );
        })}
      </div>

      {appt && (
        <div style={S.card}>
          <div style={S.h2}>Charge {appt.name}</div>
          <TaxBreakdown subtotal={appt.amount} label={appt.service} taxable={isTaxable} />

          <div style={S.mb(16)}>
            <div style={S.h3}>Payment Method</div>
            <div style={S.toggleWrap}>
              <button style={{ ...S.toggleBtn(method === "card"), flex: 1 }} onClick={() => { setMethod("card"); setPayError(""); }}>💳 Card</button>
              <button style={{ ...S.toggleBtn(method === "cash"), flex: 1 }} onClick={() => { setMethod("cash"); setPayError(""); }}>💵 Cash</button>
            </div>
          </div>

          {payError && <div style={S.errorBox}><span style={{ fontSize: 13, color: "#c00" }}>⚠️ {payError}</span></div>}

          {method === "card" && (
            <SquarePaymentForm amount={total} onSuccess={handleCardSuccess} onError={handleCardError} />
          )}

          {method === "cash" && (
            <div>
              <div style={S.mb(14)}>
                <label style={S.label}>Cash Received</label>
                <input style={{ ...S.input, fontSize: 18, fontWeight: 700 }} placeholder={`$${total.toFixed(2)}`} type="number" value={cashReceived} onChange={e => { setCashReceived(e.target.value); setPayError(""); }} />
              </div>
              {cashChange !== null && cashChange >= 0 && (
                <div style={{ background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 6, padding: 12, marginBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 13, color: "#555" }}>Change due</span>
                  <span style={{ fontSize: 18, fontWeight: 800, color: "#2e7d32" }}>${cashChange.toFixed(2)}</span>
                </div>
              )}
              {cashChange !== null && cashChange < 0 && (
                <div style={{ background: "#fde8e8", border: "1px solid #fca5a5", borderRadius: 6, padding: 12, marginBottom: 16 }}>
                  <span style={{ fontSize: 13, color: "#c00" }}>Cash received is ${Math.abs(cashChange).toFixed(2)} short</span>
                </div>
              )}
              <button style={{ ...S.btnPrimary, opacity: cashChange !== null && cashChange < 0 ? 0.5 : 1 }} onClick={handleCashPay} disabled={cashChange !== null && cashChange < 0}>
                Complete Cash Payment
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Booking Screen ───────────────────────────────────────────────────────────
function BookingScreen() {
  const { taxRate, taxMode, taxableItems } = useSettings();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ name: "", email: "", phone: "", artist: "", service: "", date: "", time: "" });
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const svc = SERVICES.find((s) => s.name === form.service);
  const isTaxable = svc ? (taxMode === "all" || taxableItems.includes(svc.name)) : false;

  if (step === 3) return (
    <div style={S.successBox}>
      <div style={{ fontSize: 36, marginBottom: 8 }}>✅</div>
      <div style={{ fontSize: 17, fontWeight: 700, marginBottom: 4 }}>Appointment Confirmed</div>
      <div style={{ fontSize: 13, color: "#555", marginBottom: 8 }}>{form.name} · {form.service} with {form.artist}<br />{form.date} at {form.time}</div>
      {svc?.price > 0 && <div style={{ fontSize: 13, color: "#555", marginBottom: 16 }}>Total: <strong>${isTaxable ? calcTotal(svc.price, taxRate).toFixed(2) : svc.price.toFixed(2)}</strong> {isTaxable ? `(incl. ${taxRate}% tax)` : "(tax exempt)"}</div>}
      <button style={{ ...S.btnPrimary, maxWidth: 200, margin: "0 auto" }} onClick={() => { setStep(1); setForm({ name: "", email: "", phone: "", artist: "", service: "", date: "", time: "" }); }}>Book Another</button>
    </div>
  );

  return (
    <div>
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {[1, 2].map(n => <div key={n} style={{ flex: 1, height: 3, borderRadius: 2, background: step >= n ? "#111" : "#e5e5e5" }} />)}
      </div>
      {step === 1 && (
        <div style={S.card}>
          <div style={S.h2}>Client Details</div>
          <div style={S.mb(14)}><label style={S.label}>Full Name</label><input style={S.input} placeholder="Jane Smith" value={form.name} onChange={e => set("name", e.target.value)} /></div>
          <div style={S.row}>
            <div style={S.col}><label style={S.label}>Email</label><input style={S.input} placeholder="jane@email.com" value={form.email} onChange={e => set("email", e.target.value)} /></div>
            <div style={S.col}><label style={S.label}>Phone</label><input style={S.input} placeholder="(555) 000-0000" value={form.phone} onChange={e => set("phone", e.target.value)} /></div>
          </div>
          <div style={S.mb(14)}><label style={S.label}>Artist</label>
            <select style={S.select} value={form.artist} onChange={e => set("artist", e.target.value)}>
              <option value="">Select artist...</option>{ARTISTS.map(a => <option key={a}>{a}</option>)}
            </select>
          </div>
          <div style={S.mb(14)}><label style={S.label}>Service</label>
            <select style={S.select} value={form.service} onChange={e => set("service", e.target.value)}>
              <option value="">Select service...</option>
              {SERVICES.map(s => {
                const taxable = taxMode === "all" || taxableItems.includes(s.name);
                return <option key={s.name}>{s.name}{s.price > 0 ? ` — $${s.price}${taxable ? ` + ${taxRate}% tax` : " (exempt)"}` : " — Free"}{s.duration ? ` · ${s.duration}` : ""}</option>;
              })}
            </select>
          </div>
          <button style={S.btnPrimary} onClick={() => setStep(2)} disabled={!form.name || !form.artist || !form.service}>Next →</button>
        </div>
      )}
      {step === 2 && (
        <div style={S.card}>
          <div style={S.h2}>Pick a Date and Time</div>
          <div style={S.mb(14)}><label style={S.label}>Date</label><input type="date" style={S.input} value={form.date} onChange={e => set("date", e.target.value)} /></div>
          <div style={S.mb(16)}>
            <label style={S.label}>Available Times</label>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {TIMES.map(t => <button key={t} style={S.btnGhost(form.time === t)} onClick={() => set("time", t)}>{t}</button>)}
            </div>
          </div>
          {svc && svc.price > 0 && <TaxBreakdown subtotal={svc.price} label={svc.name} taxable={isTaxable} />}
          <div style={S.row}>
            <button style={{ ...S.btnSecondary, flex: 1 }} onClick={() => setStep(1)}>Back</button>
            <button style={{ ...S.btnPrimary, flex: 2 }} onClick={() => setStep(3)} disabled={!form.date || !form.time}>Confirm Booking</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Cash Screen ──────────────────────────────────────────────────────────────
function CashScreen() {
  const { taxRate, taxMode } = useSettings();
  const [items, setItems] = useState([{ desc: "", amount: "", taxable: taxMode === "all" }]);
  const [saved, setSaved] = useState(false);
  const addRow = () => setItems(i => [...i, { desc: "", amount: "", taxable: taxMode === "all" }]);
  const updateRow = (idx, k, v) => setItems(i => i.map((r, j) => j === idx ? { ...r, [k]: v } : r));
  const subtotal = items.reduce((s, i) => s + (parseFloat(i.amount) || 0), 0);
  const tax = items.reduce((s, i) => s + (i.taxable ? calcTax(parseFloat(i.amount) || 0, taxRate) : 0), 0);
  const total = parseFloat((subtotal + tax).toFixed(2));

  if (saved) return (
    <div style={S.successBox}>
      <div style={{ fontSize: 36, marginBottom: 8 }}>✅</div>
      <div style={{ fontSize: 17, fontWeight: 700, marginBottom: 4 }}>Cash Sale Logged</div>
      <div style={{ fontSize: 13, color: "#555" }}>${total.toFixed(2)} total{tax > 0 ? ` (incl. $${tax.toFixed(2)} tax @ ${taxRate}%)` : " (no tax)"}</div>
      <button style={{ ...S.btnPrimary, maxWidth: 200, margin: "16px auto 0" }} onClick={() => { setItems([{ desc: "", amount: "", taxable: taxMode === "all" }]); setSaved(false); }}>Log Another</button>
    </div>
  );

  return (
    <div style={S.card}>
      <div style={S.h2}>Log Cash Sale</div>
      <div style={{ display: "flex", fontSize: 11, fontWeight: 600, color: "#999", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 8, gap: 12 }}>
        <span style={{ flex: 2 }}>Description</span><span style={{ flex: 1 }}>Amount</span><span style={{ width: 60, textAlign: "center" }}>Taxable</span>
      </div>
      {items.map((item, i) => (
        <div key={i} style={{ display: "flex", gap: 12, marginBottom: 10, alignItems: "center" }}>
          <div style={{ flex: 2 }}><input style={S.input} placeholder="Service or item" value={item.desc} onChange={e => updateRow(i, "desc", e.target.value)} /></div>
          <div style={{ flex: 1 }}><input style={S.input} placeholder="$0.00" type="number" value={item.amount} onChange={e => updateRow(i, "amount", e.target.value)} /></div>
          <div style={{ width: 60, display: "flex", justifyContent: "center" }}>
            <div style={{ width: 36, height: 20, borderRadius: 10, background: item.taxable ? "#111" : "#ddd", cursor: "pointer", position: "relative" }} onClick={() => updateRow(i, "taxable", !item.taxable)}>
              <div style={{ position: "absolute", top: 2, left: item.taxable ? 18 : 2, width: 16, height: 16, borderRadius: "50%", background: "#fff", transition: "left 0.15s" }} />
            </div>
          </div>
        </div>
      ))}
      <button style={{ ...S.btnSecondary, marginBottom: 16 }} onClick={addRow}>+ Add Item</button>
      <div style={S.divider} />
      {subtotal > 0 && (<>
        <div style={S.taxLine}><span style={{ color: "#555" }}>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
        {tax > 0 && <div style={S.taxLine}><span style={{ color: "#555" }}>Sales Tax ({taxRate}%)</span><span>${tax.toFixed(2)}</span></div>}
        <div style={S.divider} />
      </>)}
      <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 700, fontSize: 16, marginBottom: 16 }}><span>Total</span><span>${total.toFixed(2)}</span></div>
      <button style={S.btnPrimary} onClick={() => setSaved(true)} disabled={subtotal === 0}>Save Cash Sale</button>
    </div>
  );
}

// ─── Tips Screen ──────────────────────────────────────────────────────────────
function TipsScreen() {
  return (
    <div>
      <div style={S.card}>
        <div style={S.h2}>Accept Tips</div>
        <div style={{ fontSize: 13, color: "#666", marginBottom: 16 }}>Tips sent directly — no fees to anyone.</div>
        {[
          { platform: "Venmo", handle: "@DemoShop", emoji: "💜", color: "#3D95CE" },
          { platform: "Zelle", handle: "demo@shop.com", emoji: "💛", color: "#6D1ED4" },
          { platform: "Cash App", handle: "$DemoShop", emoji: "💚", color: "#00D64F" },
        ].map(({ platform, handle, emoji, color }) => (
          <div key={platform} style={S.tipBox}>
            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 4, color }}>{emoji} {platform}</div>
            <div style={S.qr}>QR</div>
            <div style={{ fontSize: 15, fontWeight: 700 }}>{handle}</div>
            <div style={{ fontSize: 11, color: "#aaa", marginTop: 4 }}>Scan or search to send a tip</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Dashboard Screen ─────────────────────────────────────────────────────────
function DashboardScreen() {
  const { taxRate } = useSettings();
  const totalCard = mockSales.reduce((s, d) => s + d.card, 0);
  const totalCash = mockSales.reduce((s, d) => s + d.cash, 0);
  const totalRevenue = totalCard + totalCash;
  const totalTax = calcTax(totalRevenue, taxRate);
  const maxVal = Math.max(...mockSales.map(d => d.card + d.cash));
  return (
    <div>
      <div style={S.statGrid}>
        <div style={S.statCard(true)}><div style={S.statNum}>${totalRevenue.toLocaleString()}</div><div style={S.statLabel(true)}>This Week (pre-tax)</div></div>
        <div style={S.statCard(false)}><div style={S.statNum}>${totalTax.toLocaleString()}</div><div style={S.statLabel(false)}>Tax Collected ({taxRate}%)</div></div>
        <div style={S.statCard(false)}><div style={S.statNum}>${totalCard.toLocaleString()}</div><div style={S.statLabel(false)}>Card Revenue</div></div>
        <div style={S.statCard(false)}><div style={S.statNum}>${totalCash.toLocaleString()}</div><div style={S.statLabel(false)}>Cash Revenue</div></div>
      </div>
      <div style={S.card}>
        <div style={S.h3}>Revenue This Week</div>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 110, marginBottom: 8 }}>
          {mockSales.map((d) => {
            const cardH = Math.round((d.card / maxVal) * 90);
            const cashH = Math.round((d.cash / maxVal) * 90);
            return (
              <div key={d.label} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
                <div style={{ width: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-end", height: 90, gap: 1 }}>
                  <div style={{ width: "70%", height: cashH, background: "#bbb", borderRadius: "3px 3px 0 0" }} />
                  <div style={{ width: "70%", height: cardH, background: "#111", borderRadius: "3px 3px 0 0" }} />
                </div>
                <div style={{ fontSize: 10, color: "#888" }}>{d.label}</div>
              </div>
            );
          })}
        </div>
        <div style={{ display: "flex", gap: 16, fontSize: 11, color: "#666" }}>
          <span><span style={{ display: "inline-block", width: 10, height: 10, background: "#111", borderRadius: 2, marginRight: 4 }} />Card</span>
          <span><span style={{ display: "inline-block", width: 10, height: 10, background: "#bbb", borderRadius: 2, marginRight: 4 }} />Cash</span>
        </div>
      </div>
      <div style={S.card}>
        <div style={S.h3}>Upcoming Appointments</div>
        {mockAppointments.map((a, i) => (
          <div key={i} style={S.apptRow}>
            <div><div style={S.apptName}>{a.name}</div><div style={S.apptSub}>{a.service} · {a.artist}</div></div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 12, fontWeight: 600 }}>{a.date}, {a.time}</div>
              <div style={S.tag(a.status === "confirmed" ? "green" : "yellow")}>{a.status}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Settings Screen ──────────────────────────────────────────────────────────
function SettingsScreen({ taxRate, setTaxRate, taxMode, setTaxMode, taxableItems, setTaxableItems }) {
  const [inputVal, setInputVal] = useState(String(taxRate));
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const handleSave = () => {
    const parsed = parseFloat(inputVal);
    if (isNaN(parsed) || parsed < 0 || parsed > 30) { setError("Enter a valid rate between 0% and 30%."); return; }
    setTaxRate(parsed); setError(""); setSaved(true); setTimeout(() => setSaved(false), 3000);
  };
  const quickSet = (val) => { setInputVal(String(val)); setTaxRate(val); setSaved(true); setTimeout(() => setSaved(false), 2500); };

  return (
    <div>
      <div style={S.card}>
        <div style={S.h2}>⚙️ Tax Settings</div>
        <div style={{ paddingBottom: 20, marginBottom: 20, borderBottom: "1px solid #f0f0f0" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <div><div style={{ fontSize: 14, fontWeight: 600 }}>Tax Rate</div><div style={{ fontSize: 12, color: "#888", marginTop: 2 }}>Columbus / Franklin County, OH</div></div>
            <div style={{ background: "#111", color: "#fff", fontSize: 14, fontWeight: 700, padding: "4px 12px", borderRadius: 6 }}>{taxRate}%</div>
          </div>
          <div style={S.infoBox}>📍 Current rate: <strong>8%</strong> (5.75% OH state + 2.25% Franklin County)</div>
          <div style={{ display: "flex", gap: 10, alignItems: "flex-end", marginBottom: 8 }}>
            <div style={{ flex: 1 }}><label style={S.label}>Tax Rate (%)</label><input style={{ ...S.input, fontSize: 20, fontWeight: 700, textAlign: "center" }} type="number" step="0.25" min="0" max="30" value={inputVal} onChange={e => { setInputVal(e.target.value); setSaved(false); setError(""); }} onKeyDown={e => e.key === "Enter" && handleSave()} /></div>
            <button style={{ ...S.btnPrimary, width: "auto", padding: "10px 24px" }} onClick={handleSave}>Save</button>
          </div>
          {error && <div style={{ color: "#c00", fontSize: 12 }}>{error}</div>}
          {saved && <div style={{ color: "#2e7d32", fontSize: 12, fontWeight: 600 }}>✓ Rate updated to {taxRate}%</div>}
          <div style={{ marginTop: 14 }}>
            <div style={S.h3}>Quick Set</div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {[{ label: "7.5% (old)", val: 7.5 }, { label: "8% (current)", val: 8.0 }, { label: "8.75%", val: 8.75 }, { label: "0% (exempt)", val: 0 }].map(({ label, val }) => (
                <button key={val} style={S.btnGhost(taxRate === val)} onClick={() => quickSet(val)}>{label}</button>
              ))}
            </div>
          </div>
        </div>
        <div>
          <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>Apply Tax To</div>
          <div style={{ fontSize: 12, color: "#888", marginBottom: 12 }}>Choose whether tax applies to everything or only specific items</div>
          <div style={S.toggleWrap}>
            <button style={S.toggleBtn(taxMode === "all")} onClick={() => setTaxMode("all")}>All transactions</button>
            <button style={S.toggleBtn(taxMode === "specific")} onClick={() => setTaxMode("specific")}>Specific items only</button>
          </div>
          {taxMode === "specific" && (
            <div>
              <label style={S.label}>Select which items are taxable</label>
              <MultiSelect options={ALL_ITEM_NAMES} selected={taxableItems} onChange={setTaxableItems} />
              {taxableItems.length === 0 && <div style={{ fontSize: 12, color: "#c00", marginTop: 8 }}>⚠️ No items selected — no tax will be charged.</div>}
              {taxableItems.length > 0 && <div style={{ marginTop: 12 }}><div style={S.h3}>Taxable items</div><div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>{taxableItems.map(item => <div key={item} style={{ ...S.tag("blue"), fontSize: 12, padding: "4px 10px" }}>{item}</div>)}</div></div>}
            </div>
          )}
          {taxMode === "all" && <div style={{ fontSize: 12, color: "#555", background: "#f5f5f5", borderRadius: 6, padding: 10 }}>✓ Tax applied to every transaction at {taxRate}%.</div>}
        </div>
      </div>

      <div style={S.card}>
        <div style={S.h3}>Square Integration</div>
        <div style={{ fontSize: 13, color: "#555", lineHeight: 1.8 }}>
          <div>• <strong>App ID:</strong> {SQUARE_APP_ID}</div>
          <div>• <strong>Environment:</strong> Sandbox (safe testing, no real charges)</div>
          <div>• <strong>Location ID:</strong> Add yours from the Square Developer Dashboard to activate card payments</div>
        </div>
      </div>

      <div style={S.card}>
        <div style={S.h3}>Notes for Your CPA</div>
        <div style={{ fontSize: 13, color: "#555", lineHeight: 1.8 }}>
          <div>• Pre-tax revenue and tax collected tracked separately in Dashboard</div>
          <div>• Ohio returns due the <strong>23rd of the following month</strong> at tax.ohio.gov</div>
        </div>
      </div>
      <div style={S.warnBox}>⚠️ This app calculates and tracks tax but does not file or remit on your behalf.</div>
    </div>
  );
}

// ─── App Shell ────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState("booking");
  const [taxRate, setTaxRate] = useState(8.0);
  const [taxMode, setTaxMode] = useState("all");
  const [taxableItems, setTaxableItems] = useState([...ALL_ITEM_NAMES]);
  const headerLabel = taxMode === "all" ? `${taxRate}% (all)` : `${taxRate}% (${taxableItems.length} items)`;
  const screens = {
    booking: <BookingScreen />,
    checkout: <CheckoutScreen />,
    cash: <CashScreen />,
    tips: <TipsScreen />,
    dashboard: <DashboardScreen />,
    settings: <SettingsScreen taxRate={taxRate} setTaxRate={setTaxRate} taxMode={taxMode} setTaxMode={setTaxMode} taxableItems={taxableItems} setTaxableItems={setTaxableItems} />,
  };
  return (
    <SettingsContext.Provider value={{ taxRate, taxMode, taxableItems }}>
      <div style={S.app}>
        <header style={S.header}>
          <div style={S.logo}>Demo Shop</div>
          <div style={S.taxBadge}>Tax: {headerLabel}</div>
        </header>
        <nav style={S.nav}>
          {NAV_ITEMS.map(({ id, label, icon }) => (
            <button key={id} style={S.navBtn(screen === id)} onClick={() => setScreen(id)}><span>{icon}</span>{label}</button>
          ))}
        </nav>
        <main style={S.main}>{screens[screen]}</main>
      </div>
    </SettingsContext.Provider>
  );
}
